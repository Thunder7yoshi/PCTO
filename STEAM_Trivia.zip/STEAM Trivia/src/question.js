//#region constants
const countries = {
    DE: "in Germania",
    PL: "in Polonia",
    IT: "in Italia",
    GB: "nel Regno Unito",
    RS: "in Serbia",
    US: "negli Stati Uniti",
    IN: "in India",
    AT: "in Austria"
};

const pers = [{
    nome: "Albert",
    cognome: "Einstein",
    sesso: "Maschio",
    _nazionalita: "DE",
    ambito: ["Fisica"],
    annoNascita: "1879",
    contributi: ["ha teorizzato la teoria della relativita'?", "ha dimostrato l'effetto fotoelettrico?"],
    premi: [{
        tipo: "Nobel",
        anno: "1921",
        ambito: "Fisica"
    }]
}, {
    nome: "Marie",
    cognome: "Curie",
    sesso: "Femmina",
    _nazionalita: "PL",
    ambito: ["Chimica", "Fisica"],
    annoNascita: "1867",
    contributi: ["ha scoperto il radio?", "ha scoperto il polonio?", "ha fatto ricerche sulla radioattivita'?"],
    premi: [{
        tipo: "Nobel",
        anno: "1903",
        ambito: "Fisica"
    }, {
        tipo: "Nobel",
        anno: "1911",
        ambito: "Chimica"
    }]
}, {
    nome: "Leonardo",
    cognome: "da Vinci",
    sesso: "Maschio",
    _nazionalita: "IT",
    ambito: ["Arte", "Scienza"],
    annoNascita: "1452",
    contributi: ["ha realizzato La Gioconda?", "ha realizzato L'Ultima Cena?", "e' conosciuto per i suoi studi di anatomia?"],
    premi: []
}, {
    nome: "Ada",
    cognome: "Lovelace",
    sesso: "Femmina",
    _nazionalita: "GB",
    ambito: ["Matematica", "Informatica"],
    annoNascita: "1815",
    contributi: ["ha lavorato con Charles Babbage?"],
    premi: []
}, {
    nome: "Isaac",
    cognome: "Newton",
    sesso: "Maschio",
    _nazionalita: "GB",
    ambito: ["Fisica", "Matematica"],
    annoNascita: "1643",
    contributi: ["e' l'autore di un'opera intitolata Principia Mathematica?", "ha teorizzato la legge di gravitazione universale?", "ha contribuito al calcolo differenziale?"],
    premi: []
}, {
    nome: "Nikola",
    cognome: "Tesla",
    sesso: "Maschio",
    _nazionalita: "RS",
    ambito: ["Ingegneria Elettrica"],
    annoNascita: "1856",
    contributi: ["ha brevettato la corrente alternata?", "e' famoso per aver dimostrato la trasmissione senza fili?", "ha contribuito allo sviluppo del motore a induzione?"],
    premi: []
}, {
    nome: "Galileo",
    cognome: "Galilei",
    sesso: "Maschio",
    _nazionalita: "IT",
    ambito: ["Astronomia", "Fisica"],
    annoNascita: "1564",
    contributi: ["ha apportato miglioramenti al telescopio?", "e' conosciuto per le sue osservazioni astronomiche?", "ha teorizzato le leggi del moto?"],
    premi: []
}, {
    nome: "Rosalind",
    cognome: "Franklin",
    sesso: "Femmina",
    _nazionalita: "GB",
    ambito: ["Biologia", "Chimica"],
    annoNascita: "1920",
    contributi: ["e' conosciuto per le ricerche sulla struttura del DNA?", "ha lavorato con carbone e grafite?"],
    premi: []
}, {
    nome: "Alan",
    cognome: "Turing",
    sesso: "Maschio",
    _nazionalita: "GB",
    ambito: ["Informatica", "Matematica"],
    annoNascita: "1912",
    contributi: ["ha fondato l'informatica teorica?", "ha contribuito in gran parte alla decrittazione del codice Enigma?"],
    premi: []
}, {
    nome: "Jane",
    cognome: "Goodall",
    sesso: "Femmina",
    _nazionalita: "GB",
    ambito: ["Etologia", "Antropologia"],
    annoNascita: "1934",
    contributi: ["ha studiato i comportamenti sociali e familiari degli scimpanze'?"],
    premi: []
}, {
    nome: "Stephen",
    cognome: "Hawking",
    sesso: "Maschio",
    _nazionalita: "GB",
    ambito: ["Fisica Teorica", "Cosmologia"],
    annoNascita: "1942",
    contributi: ["ha contribuito alla ricerca sui buchi neri?", "e' noto per il suo fenomeno si radiazione?", "e' noto per aver fatto ricerca sulla cosmologia quantistica?"],
    premi: [{
        tipo: "Medaglia Presidenziale della Libertà",
        anno: "2009",
        ambito: "Generale"
    }]
}, {
    nome: "Katherine",
    cognome: "Johnson",
    sesso: "Femmina",
    _nazionalita: "US",
    ambito: ["Matematica"],
    annoNascita: "1918",
    contributi: ["ha contribuito alle missioni spaziali della NASA con i suoi calcoli?"],
    premi: []
}, {
    nome: "Tim",
    cognome: "Berners-Lee",
    sesso: "Maschio",
    _nazionalita: "GB",
    ambito: ["Informatica"],
    annoNascita: "1955",
    contributi: ["ha inventato il World Wide Web?"],
    premi: [{
        tipo: "Turing",
        anno: "2016",
        ambito: "Informatica"
    }]
}, {
    nome: "Carl",
    cognome: "Sagan",
    sesso: "Maschio",
    _nazionalita: "US",
    ambito: ["Astronomia", "Astrofisica"],
    annoNascita: "1934",
    contributi: ["e' conosciuto per aver popolarizzato la scienza?", "ha partecipato alla serie TV \"Cosmos: Odissea nello spazio\"?", "ha realizzato ricerche sull'atmosfera di Venere?"],
    premi: []
}, {
    nome: "Margaret",
    cognome: "Hamilton",
    sesso: "Femmina",
    _nazionalita: "US",
    ambito: ["Informatica", "Ingegneria Software"],
    annoNascita: "1936",
    contributi: ["ha sviluppato del software di volo per le missioni Apollo?"],
    premi: []
}, {
    nome: "Srinivasa",
    cognome: "Ramanujan",
    sesso: "Maschio",
    _nazionalita: "IN",
    ambito: ["Matematica"],
    annoNascita: "1887",
    contributi: ["ha contribuito alla teoria dei numeri?", "e' conosciuto per le sue funzioni mock theta? ", "ha dato un grosso contributo circa le frazioni continue?"],
    premi: []
}, {
    nome: "Richard",
    cognome: "Feynman",
    sesso: "Maschio",
    _nazionalita: "US",
    ambito: ["Fisica"],
    annoNascita: "1918",
    contributi: ["ha contribuito all'elettrodinamica quantistica?", "e' conosciuto per i suoi diagrammi?"],
    premi: [{
        tipo: "Nobel",
        anno: "1965",
        ambito: "Fisica"
    }]
}, {
    nome: "Leonardo",
    cognome: "Fibonacci",
    sesso: "Maschio",
    _nazionalita: "IT",
    ambito: ["Matematica"],
    annoNascita: "1170",
    contributi: ["e' noto per la sua serie matematica?", "ha introdotto i numeri arabi in Europa?"],
    premi: []
}, {
    nome: "Hedy",
    cognome: "Lamarr",
    sesso: "Femmina",
    _nazionalita: "AT",
    ambito: ["Tecnologia"],
    annoNascita: "1914",
    contributi: ["ha inventato il sistema di frequency-hopping spread spectrum?", "ha contribuito allo sviluppo della tecnologia Bluetooth e Wi-Fi?"],
    premi: []
}, {
    nome: "Mae",
    cognome: "Jemison",
    sesso: "Femmina",
    _nazionalita: "US",
    ambito: ["Medicina", "Astronautica"],
    annoNascita: "1956",
    contributi: ["e' stata la prima donna afroamericana a volare nello spazio?", "ha lavorato sulla ricerca medica in microgravità?"],
    premi: []
}];
//#endregion

let lastVal = null;
let lastCategory = null;
let genderAsked = 0;
let p = pers;
const questions = [];

const randomFrom = (arr, strength = 1) => {
    const len = arr.length;
    //Strength rappresenta quanto le risposte si spostano verso le piu' comuni tra i personaggi per un filtro maggiore...
    return arr[Math.floor(Math.pow(Math.random(), strength) * len)];
}

const possibilities = (pers, category) => {
    const outcomes = {};
    for(const outcome of pers.map(p => p[category]).flat()) {
        if(!Object.keys(outcomes).some(o => o === outcome)) outcomes[outcome] = 0;
        else outcomes[outcome] += 1;
    }
    return Object.entries(outcomes).sort(([, a], [, b]) => b - a).map(([key, val]) => key);
};

const makeQuery = (pers, category) => {
    let q;
    let which = randomFrom(possibilities(pers, category));
    switch(category) {
        case 'sesso':
            q = `Il tuo personaggio e' ${which.toLowerCase()}?`;
        break;
        case '_nazionalita':
            q = `Il tuo personaggio e' nato ${countries[which]}?`;
        break;
        case 'ambito':
            q = `Il tuo personaggio fa ${which}?`;
        break;
        case 'annoNascita':
            q = `Il tuo personaggio e' nato nell'anno ${which}?`;
        break;
        case 'contributi':
            q = `Il tuo personaggio ${which}`;
        break;
        case 'premi':
            q = randomFrom(['Il tuo personaggio ha ottenuto qualche premio di rilevanza?', ...pers.map(p => p.premi).flat().map(premio => `Il tuo personaggio ha conseguito il premio ${premio.tipo}${premio.ambito === 'Generale' ? '' : ` per la ${premio.ambito}`} nel ${premio.anno}?`)]);
            if(isNaN(q.slice(-5, -1))) which = null;
            else which = q.slice(-5, -1);
        break;
    }
    return [q, which];
}

const narrowSearch = (categories) => {
    const category = randomFrom(categories);
    let arr = makeQuery(p, category);
    if(questions.some(question => question === category + '#' + arr[1])) return narrowSearch(categories);
    const [q, val] = arr;
    questions.push(category + '#' + val);
    console.log()
    console.log(questions.some(question => question === arr.category + '#' + arr.val));
    document.getElementById('question').innerText = q;
    lastVal = val;
    lastCategory = category;
    if(category === 'sesso') genderAsked += 1;
}
narrowSearch(Object.keys(pers[0]).slice(2));


let checkAnswer = bool => {
    // console.log(lastVal);
    // console.log(lastCategory);
    // console.log(bool);
    document.getElementById('question').innerText = '';
    if(bool === 'yes') bool = true;
    else bool = false;

    p = p.filter(_p => {
        if(lastCategory === 'premi' && lastVal === null) {
            if(_p[lastCategory].length > 0) return bool;
            else return !bool;
        }
        else if(lastCategory === 'premi' && lastVal !== null) {
            if(_p[lastCategory].length > 0 && _p[lastCategory].some(premio => premio.anno === lastVal)) return bool;
            else return !bool;
        }

        if(typeof _p[lastCategory] === 'string') {
            if(_p[lastCategory] === lastVal) return bool;
            else return !bool;
        }
        else if (typeof _p[lastCategory] === 'object' && typeof _p[lastCategory][0] === 'string') {
            if(_p[lastCategory].some(entry => entry === lastVal)) return bool;
            else return !bool;
        }
    });
    console.log(p);
    if(p.length > 1) narrowSearch(questions.length >= 3 ? Object.keys(pers[0]).slice(2 + genderAsked) : Object.keys(pers[0]).slice(2 + genderAsked, 5));
    else if (p.length === 0) {
        document.getElementById('question').innerText = 'Non esiste un personaggio con le caratteristiche proposte';
        document.getElementById('2').remove();
        const button  = document.getElementById('1');
        button.innerText = 'Torna al menu\'';
        button.onclick = () => window.location.href = '../index.html';
    }
    else {
        document.getElementById('question').innerText = p[0].nome + ' ' + p[0].cognome;
        document.getElementById('2').remove();
        const button  = document.getElementById('1');
        button.innerText = 'Torna al menu\'';
        button.onclick = () => window.location.href = '../index.html';
    }
    console.log(questions);
}